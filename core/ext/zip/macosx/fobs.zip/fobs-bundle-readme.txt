Extracted from : fobs4jmf_0.4.1_macosx.zip
On date        : Fri Apr 13 18:03:52 PDT 2007
